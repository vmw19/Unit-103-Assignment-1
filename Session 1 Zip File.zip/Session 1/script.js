console.log("Script");
const URL="https://sdgku.edu/"

console.log(URL);

client="San Diego Global Knowledge University Potential Students";

console.log(client);
console.log("Please, "+client+ "visit the site" + `https://sdgku.edu/`);

let schoolName="San Diego Global Knowledge University";
let physicalAddress="1095 K Street, Suite B";
let geoLocation="San Diego, CA 92101";
let schoolEmailaddress="info@sdgku.edu";
let schoolPhonenumber="1-619-934-0797";
let officeHours="Mon.-Fri. (9am-5pm PST)";
let presidentandCEOname="Dr. Miguel Cardenas";
let nationalAccreditation="Accrediting Council for Independent Colleges and Schools";
let programListNumber="four";
let modality="Online and Hybrid";
let programNameone="Full Stack Development Immersive";
let programNametwo= "B.S. Global Management";
let programNamethree="M.S. International Management";
let programNamefour="M.S. Communication and Technology";
let myProgramname="Full Stack Development Immersive";
let myInstructorName="Dr.Samantha Jimenez";
let myInstructoremailAddress= "sjimenez@sdgku.edu";
let studentTutorname= "Shay Cerny";
let studentTutoremailAddress= "scerny@sdgku.edu";
let videoConferencing="Synchronous";
let canvasLearningmangementSystemName="Canvas LMS ";
let SDGKULearningmanagementSystemName="SDGKU LMS";
let dualCurriculum="Academic and Competency-Based";

console.log("client");
//console.log(","+ , + ".");
//template string
document.write(`Introducing the prestigious, distinguished, highly esteemed private university: ${schoolName}. We are located at ${physicalAddress} ${geoLocation} $. You can contact us by email at ${schoolEmailaddress} or we are always a phone call away at ${schoolPhonenumber}. We are available during the following days and times ${officeHours}. In 2007, SDGKU was founded by ${presidentandCEOname} who had a vision to "provide virtual classrooms with a global outreach". Furthermore, we are accredited by the ${nationalAccreditation}. Come learn and grow with us!! You can study from anywhere in the world. Our modilities include ${modality} formats. We have a total of ${programListNumber} programs. Our programs include ${programNameone}, ${programNametwo}, ${programNamethree}, and ${programNamefour}. My specific program is ${myProgramname}. My professor is ${myInstructorName}. Her email address is ${myInstructoremailAddress}. Tutoring is always available for students. The tutor for our program is ${studentTutorname} and his email address is ${studentTutoremailAddress}. The video conferencing format is ${videoConferencing}. Our learning platforms are${canvasLearningmangementSystemName} and${SDGKULearningmanagementSystemName}. The dual curriculum is ${dualCurriculum} and extremely challenging. We welcome you to apply to one of our programs today!`);